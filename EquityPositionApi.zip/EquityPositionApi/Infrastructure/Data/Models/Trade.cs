﻿using System.ComponentModel.DataAnnotations;

namespace Infrastructure.Data.Models;

public class Trade
{
    [Key]
    public int TradeId { get; set; }
    public int Version { get; set; }
    public string SecurityCode { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public string Direction { get; set; } = string.Empty;
    public bool IsCancelled { get; set; }
    public DateTime LastUpdatedAt { get; set; }
}
