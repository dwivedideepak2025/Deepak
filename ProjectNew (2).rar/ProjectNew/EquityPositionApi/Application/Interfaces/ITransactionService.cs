﻿using System.Transactions;
using Domain.Entities;


namespace Application.Interfaces;

public interface ITransactionService
{
    Task AddTransactionAsync(Domain.Entities.TransactionEntity transaction);
    Task<Dictionary<string, int>> GetPositionsAsync();
}
