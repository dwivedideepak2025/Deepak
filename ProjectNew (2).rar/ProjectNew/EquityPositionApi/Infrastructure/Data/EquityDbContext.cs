﻿using Microsoft.EntityFrameworkCore;
using Infrastructure.Data.Models;

namespace Infrastructure.Data
{
    public class EquityDbContext : DbContext
    {
        public EquityDbContext(DbContextOptions<EquityDbContext> options) : base(options) { }

        public DbSet<Transaction> Transactions { get; set; } = null!;
        public DbSet<Trade> Trades { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Transaction>().ToTable("Transactions");
            modelBuilder.Entity<Transaction>().HasKey(t => t.TransactionId);

            modelBuilder.Entity<Trade>(entity =>
            {
                entity.ToTable("Trades");
                entity.HasKey(t => t.TradeId);
            });
        }
    }
}
