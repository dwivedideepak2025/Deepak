﻿using Application.Interfaces;
using Domain.Entities;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Services;

public class TransactionService : ITransactionService
{
    private readonly EquityDbContext _context;

    public TransactionService(EquityDbContext context)
    {
        _context = context;
    }

    public async Task AddTransactionAsync(Domain.Entities.TransactionEntity transaction)
    {
        var existing = await _context.Transactions
            .Where(t => t.TradeId == transaction.TradeId)
            .OrderByDescending(t => t.Version)
            .FirstOrDefaultAsync();

        if (existing != null && transaction.Version <= existing.Version)
            return;

        var dbTransaction = new Infrastructure.Data.Models.Transaction
        {
            TradeId = transaction.TradeId,
            Version = transaction.Version,
            SecurityCode = transaction.SecurityCode,
            Quantity = transaction.Quantity,
            Action = transaction.Action,
            Direction = transaction.Direction,
            CreatedAt = transaction.CreatedAt
        };

        _context.Transactions.Add(dbTransaction);
        await _context.SaveChangesAsync();
    }


    public async Task<Dictionary<string, int>> GetPositionsAsync()
    {
        var latestTrades = await _context.Transactions
            .GroupBy(t => t.TradeId)
            .Select(g => g.OrderByDescending(t => t.Version).First())
            .ToListAsync();

        var positions = new Dictionary<string, int>();

        foreach (var trade in latestTrades)
        {
            if (!positions.ContainsKey(trade.SecurityCode))
                positions[trade.SecurityCode] = 0;

            if (trade.Action == "CANCEL") continue;

            var multiplier = trade.Direction.ToUpper() == "BUY" ? 1 : -1;
            positions[trade.SecurityCode] += trade.Quantity * multiplier;
        }

        return positions;
    }

}
