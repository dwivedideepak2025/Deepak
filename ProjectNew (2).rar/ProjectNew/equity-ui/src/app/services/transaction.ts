import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Transaction } from '../models/transaction.model';

@Injectable({ providedIn: 'root' })
export class TransactionService {
  private apiUrl = 'https://localhost:7145/api/transaction';

  constructor(private http: HttpClient) {}

  addTransaction(tx: Transaction): Observable<any> {
    return this.http.post(this.apiUrl, tx);
  }
}
