import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PositionService } from '../../services/position';
import { Position } from '../../models/position.model';

@Component({
  selector: 'app-positions',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './positions.html',
  styleUrls: ['./positions.scss']
})
export class Positions {
  positions: Position[] = [];

  constructor(private positionService: PositionService) {}

  ngOnInit(): void {
    this.positionService.getPositions().subscribe(data => this.positions = data);
  }
}