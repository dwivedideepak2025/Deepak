import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TransactionService } from '../../services/transaction';
import { Transaction } from '../../models/transaction.model';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-transactions',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './transactions.html',
  styleUrls: ['./transactions.scss']
})
export class Transactions implements OnInit {
  newTx: Transaction = {
    tradeId: 0,
    version: 1,
    securityCode: '',
    quantity: 0,
    action: 'INSERT',
    direction: 'BUY'
  };

  message: string = '';
  positions: { [key: string]: number } = {};
  positionsKeys: string[] = [];

  constructor(private txService: TransactionService, private http: HttpClient) {}

  ngOnInit(): void {
    this.loadPositions();
  }

  submit() {
    this.txService.addTransaction(this.newTx).subscribe({
      next: res => {
        this.message = res.message || 'Transaction submitted!';
        this.resetForm();
        this.loadPositions(); // Refresh positions
      },
      error: err => {
        this.message = 'Error submitting transaction';
        console.error(err);
      }
    });
  }

  private resetForm() {
    this.newTx = {
      tradeId: 0,
      version: 1,
      securityCode: '',
      quantity: 0,
      action: 'INSERT',
      direction: 'BUY'
    };
  }

  private loadPositions() {
    this.http.get<{ [key: string]: number }>('/api/transaction/positions')
      .subscribe(pos => {
        this.positions = pos;
        this.positionsKeys = Object.keys(pos);
      });
  }
}
