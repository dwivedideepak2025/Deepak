import { Routes } from '@angular/router';
import { Transactions } from './components/transactions/transactions';
import { Positions } from './components/positions/positions';

export const routes: Routes = [
  { path: '', redirectTo: 'transactions', pathMatch: 'full' },
  { path: 'transactions', component: Transactions },
  { path: 'positions', component: Positions }
];
