export interface Transaction {
  tradeId: number;
  version: number;
  securityCode: string;
  quantity: number;
  action: 'INSERT' | 'UPDATE' | 'CANCEL';
  direction: 'BUY' | 'SELL';
}
