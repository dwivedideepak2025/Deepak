export interface Position {
  securityCode: string;
  quantity: number;
}
